#ifndef __CHAINSTACK_H
#define __CHAINSTACK_H

typedef struct stackNode {
    int val;
    struct stackNode *next;
}stackNode;


#endif